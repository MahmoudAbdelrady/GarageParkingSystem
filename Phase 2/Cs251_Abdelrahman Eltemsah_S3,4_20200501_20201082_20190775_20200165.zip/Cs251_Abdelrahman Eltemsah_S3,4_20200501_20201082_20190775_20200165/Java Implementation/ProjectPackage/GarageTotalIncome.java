package ProjectPackage;

public class GarageTotalIncome {
    public static double TotalIncome(){
        return ParkOut.totalIncome;
    }
}
